Testing
=======

Potemkin-Stack
--------------

Start app

    docker-compose up -d

Find port

    docker-compose ps
    
   